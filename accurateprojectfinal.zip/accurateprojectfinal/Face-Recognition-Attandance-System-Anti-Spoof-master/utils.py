import tkinter as tk
from tkinter import messagebox


def get_button(window, text, color, command, fg='white'):
    # Define hover effect functions
    def on_enter(e):
        button['background'] = hover_color
        button['foreground'] = 'white'
        
    def on_leave(e):
        button['background'] = color
        button['foreground'] = fg
    
    # Create darker hover color
    r, g, b = window.winfo_rgb(color)
    r = max(0, int(r/256) - 40)
    g = max(0, int(g/256) - 40)
    b = max(0, int(b/256) - 40)
    hover_color = f'#{r:02x}{g:02x}{b:02x}'
    
    button = tk.Button(
                        window,
                        text=text,
                        activebackground="#444444",
                        activeforeground="white",
                        fg=fg,
                        bg=color,
                        command=command,
                        height=2,
                        width=20,
                        font=('Helvetica bold', 20),
                        relief=tk.GROOVE,
                        borderwidth=3,
                        cursor="hand2",
                        padx=15,
                        pady=8,
                        highlightthickness=2,
                        highlightbackground="#555555",
                        highlightcolor="white"
                    )
    
    # Bind hover events
    button.bind("<Enter>", on_enter)
    button.bind("<Leave>", on_leave)

    return button


def get_img_label(window):
    label = tk.Label(window)
    label.grid(row=0, column=0)
    return label


def get_text_label(window, text):
    label = tk.Label(window, text=text)
    label.config(font=("sans-serif", 21), justify="left")
    return label


def get_entry_text(window):
    inputtxt = tk.Text(window,
                       height=2,
                       width=15, font=("Arial", 32))
    return inputtxt


def msg_box(title, description):
    messagebox.showinfo(title, description)
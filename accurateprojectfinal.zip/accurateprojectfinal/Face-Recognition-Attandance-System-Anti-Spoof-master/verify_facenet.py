import torch
import numpy as np
from facenet_pytorch import MTCNN, InceptionResnetV1
from PIL import Image

def verify_facenet():
    print("Verifying FaceNet integration...")
    
    # Check CUDA availability
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")
    
    try:
        # Initialize MTCNN
        print("Initializing MTCNN...")
        mtcnn = MTCNN(keep_all=False, select_largest=True, device=device)
        print("MTCNN initialized.")
        
        # Initialize InceptionResnetV1
        print("Initializing InceptionResnetV1...")
        resnet = InceptionResnetV1(pretrained='vggface2').eval().to(device)
        print("InceptionResnetV1 initialized.")
        
        # Create a dummy image (RGB)
        print("Creating dummy image...")
        dummy_img = Image.fromarray(np.random.randint(0, 255, (200, 200, 3), dtype=np.uint8))
        
        # Detect face (might fail on random noise, so let's just test the embedding generation on the dummy image directly if detection fails, 
        # but MTCNN expects a face. Actually, let's just feed the dummy image to MTCNN and handle the 'None' result gracefully, 
        # or better, manually preprocess a tensor for resnet to test that part.)
        
        # Test ResNet forward pass with a dummy tensor
        print("Testing embedding generation...")
        dummy_tensor = torch.randn(1, 3, 160, 160).to(device)
        embedding = resnet(dummy_tensor)
        
        print(f"Embedding shape: {embedding.shape}")
        print("Verification SUCCESS: FaceNet components are working.")
        return True
        
    except Exception as e:
        print(f"Verification FAILED: {e}")
        return False

if __name__ == "__main__":
    verify_facenet()

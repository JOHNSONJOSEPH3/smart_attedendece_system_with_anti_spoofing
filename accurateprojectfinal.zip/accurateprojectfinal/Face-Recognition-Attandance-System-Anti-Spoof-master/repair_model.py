import os
import cv2
import numpy as np
from PIL import Image
import json

def train_model():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    departments_dir = os.path.join(current_dir, 'departments')
    known_people_dir = os.path.join(current_dir, 'known_people')
    trainer_dir = os.path.join(current_dir, 'trainer')
    
    if not os.path.exists(trainer_dir):
        os.makedirs(trainer_dir)

    print("Starting model training...")
    
    faces = []
    ids = []
    names = {}
    current_id = 0
    
    # 1. Process Departments (Students)
    if os.path.exists(departments_dir):
        for dept_name in os.listdir(departments_dir):
            dept_path = os.path.join(departments_dir, dept_name)
            if not os.path.isdir(dept_path):
                continue
                
            for class_name in os.listdir(dept_path):
                class_dir = os.path.join(dept_path, class_name)
                if not os.path.isdir(class_dir):
                    continue
                    
                for image_name in os.listdir(class_dir):
                    image_path = os.path.join(class_dir, image_name)
                    
                    try:
                        # Read image
                        img_pil = Image.open(image_path).convert('L') # Convert to grayscale
                        image_np = np.array(img_pil, 'uint8')
                        
                        # Get name from filename (remove extension)
                        name = os.path.splitext(image_name)[0].lower()
                        
                        # Assign ID if new name
                        if name not in [v['name'] for v in names.values()]:
                            current_id += 1
                            names[str(current_id)] = {'name': name, 'department': dept_name, 'class': class_name}
                            print(f"New User: {name} (ID: {current_id})")
                        
                        # Find the ID for this name
                        label_id = -1
                        for k, v in names.items():
                            if v['name'] == name:
                                label_id = int(k)
                                break
                        
                        if label_id != -1:
                            # Detect face in the training image
                            face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
                            detected_faces = face_cascade.detectMultiScale(image_np)
                            
                            if len(detected_faces) == 0:
                                print(f"WARNING: No face detected in {image_path}. This image will be ignored.")
                            else:
                                print(f"Processing {image_name} for {name} (ID: {label_id})")
                                for (x, y, w, h) in detected_faces:
                                    faces.append(image_np[y:y+h, x:x+w])
                                    ids.append(label_id)
                    except Exception as e:
                        print(f"Error processing {image_name}: {e}")

    # 2. Process Known People
    if os.path.exists(known_people_dir):
        for image_name in os.listdir(known_people_dir):
            if not (image_name.endswith('.jpg') or image_name.endswith('.png')):
                continue
                
            image_path = os.path.join(known_people_dir, image_name)
            
            try:
                # Read image
                img_pil = Image.open(image_path).convert('L')
                image_np = np.array(img_pil, 'uint8')
                
                name = os.path.splitext(image_name)[0].lower()
                
                if name not in [v['name'] for v in names.values()]:
                    current_id += 1
                    names[str(current_id)] = {'name': name, 'department': 'Unknown', 'class': 'Unknown'}
                    print(f"New User: {name} (ID: {current_id})")
                
                label_id = -1
                for k, v in names.items():
                    if v['name'] == name:
                        label_id = int(k)
                        break
                
                if label_id != -1:
                    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
                    detected_faces = face_cascade.detectMultiScale(image_np)
                    
                    if len(detected_faces) == 0:
                        print(f"WARNING: No face detected in {image_path}. This image will be ignored.")
                    else:
                        print(f"Processing {image_name} for {name} (ID: {label_id})")
                        for (x, y, w, h) in detected_faces:
                            faces.append(image_np[y:y+h, x:x+w])
                            ids.append(label_id)
            except Exception as e:
                print(f"Error processing {image_name}: {e}")

    if len(faces) > 0 and len(ids) > 0:
        # Train the recognizer
        print(f"Training model with {len(faces)} faces...")
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        recognizer.train(faces, np.array(ids))
        
        # Filter names to only include those with training data
        used_ids = set(ids)
        final_names = {k: v for k, v in names.items() if int(k) in used_ids}
        
        # Save the model
        recognizer.save(os.path.join(trainer_dir, 'classifier.xml'))
        
        # Save the name mapping
        with open(os.path.join(trainer_dir, 'names.json'), 'w') as f:
            json.dump(final_names, f, indent=4)
        
        print(f"Model trained and saved successfully with {len(final_names)} people.")
        print("Note: Check above for any warnings about skipped images.")
    else:
        print("No faces found to train.")

if __name__ == "__main__":
    train_model()

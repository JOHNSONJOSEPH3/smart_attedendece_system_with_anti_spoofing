@echo off
"C:\Users\JOHN JOY\anaconda3\python.exe" main.py
pause
import os
import subprocess
import datetime
import tkinter as tk
from tkinter import ttk, filedialog, simpledialog, messagebox
import cv2
import utils
import json
import numpy as np
from PIL import Image, ImageTk, ImageDraw
from test import test
import pandas as pd
import threading
import time
import math
import shutil
import re
import torch
from facenet_pytorch import MTCNN, InceptionResnetV1


class App:
    def __init__(self):
        self.main_window = tk.Tk()
        self.main_window.title("Face Recognition Attendance System")
        #width  x height
        self.auto_login_timer = None
        self.login_scheduled = False
        self.face_absent_timer = None
        self.last_face_detected_time = None
        self.face_detection_active = False
        self.logout_countdown = 10  # 10 seconds for logout timer
        self.main_window.geometry('1200x700')  # Increased height to accommodate new buttons
        
        # Current user tracking
        self.current_user = None
        self.current_department = None
        self.current_class = None
        self.logged_in = False
        self.student_data = {}
        self.period_start_job = None
        self.period_end_job = None
        self.period_active = False
        self.period_start_dt = None
        self.period_end_dt = None
        
        # Create data directories if they don't exist
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        self.departments_dir = os.path.join(self.current_dir, 'departments')
        self.unknown_dir = os.path.join(self.current_dir, 'unknown_people')
        self.attendance_dir = os.path.join(self.current_dir, 'attendance_data')
        self.student_data_dir = os.path.join(self.current_dir, 'student_data')
        self.known_people_dir = os.path.join(self.current_dir, 'known_people')
        self.trainer_dir = os.path.join(self.current_dir, 'trainer')
        
        # Create necessary directories
        os.makedirs(self.departments_dir, exist_ok=True)
        os.makedirs(self.unknown_dir, exist_ok=True)
        os.makedirs(self.attendance_dir, exist_ok=True)
        os.makedirs(self.student_data_dir, exist_ok=True)
        os.makedirs(self.trainer_dir, exist_ok=True)
        
        # Initialize department and class structure if it doesn't exist
        self.departments_db = os.path.join(self.current_dir, 'departments.json')
        if not os.path.exists(self.departments_db):
            with open(self.departments_db, 'w') as f:
                json.dump({}, f)
        
        # Initialize student data database if it doesn't exist
        self.student_db = os.path.join(self.student_data_dir, 'students.json')
        if not os.path.exists(self.student_db):
            with open(self.student_db, 'w') as f:
                json.dump({}, f)
        
        # Initialize attendance database if it doesn't exist
        self.attendance_db = os.path.join(self.attendance_dir, 'attendance.json')
        if not os.path.exists(self.attendance_db):
            with open(self.attendance_db, 'w') as f:
                json.dump({}, f)
                
        # Load departments and classes
        self.load_departments()
        
        # Initialize Face Recognizer
        self.face_recognizer = None
        self.user_map = {}
        self.load_face_recognizer()
        
        # Initialize Deep Face Recognition (FaceNet)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # Initialize MTCNN for face detection (used for embedding generation)
        self.mtcnn = MTCNN(keep_all=False, select_largest=True, device=self.device)
        
        # Initialize InceptionResnetV1 for face recognition
        self.resnet = InceptionResnetV1(pretrained='vggface2').eval().to(self.device)
        
        self.known_embeddings = []
        self.load_deep_face_embeddings()
        
        self.login_duration = 2
        self.logout_duration = 10
        self.recognition_threshold_percent = 70
        self.recognition_threshold_distance = 55

        # Status Label
        self.status_label = utils.get_text_label(self.main_window, 'Not logged in')
        self.status_label.config(font=("Arial", 16, "bold"), fg="red")
        self.status_label.place(x=750, y=50)

        def safe_update_status(text, fg):
            try:
                if getattr(self, 'status_label', None) is None or not self.status_label.winfo_exists():
                    self.status_label = utils.get_text_label(self.main_window, text)
                    self.status_label.config(font=("Arial", 16, "bold"), fg=fg)
                    self.status_label.place(x=750, y=50)
                else:
                    self.status_label.config(text=text, fg=fg)
            except tk.TclError:
                try:
                    self.status_label = utils.get_text_label(self.main_window, text)
                    self.status_label.config(font=("Arial", 16, "bold"), fg=fg)
                    self.status_label.place(x=750, y=50)
                except Exception:
                    pass
        self.safe_update_status = safe_update_status

        # Timer Settings Row
        tk.Label(self.main_window, text="Login(s)", font=("Arial", 10)).place(x=750, y=100)
        self.login_duration_var = tk.IntVar(value=self.login_duration)
        tk.Spinbox(self.main_window, from_=1, to=60, textvariable=self.login_duration_var, width=5).place(x=810, y=100)
        
        tk.Label(self.main_window, text="Logout(s)", font=("Arial", 10)).place(x=870, y=100)
        self.logout_duration_var = tk.IntVar(value=self.logout_duration)
        tk.Spinbox(self.main_window, from_=1, to=60, textvariable=self.logout_duration_var, width=5).place(x=940, y=100)
        
        self.apply_timers_btn = utils.get_button(self.main_window, 'Apply Timers', 'teal', self.apply_timers)
        self.apply_timers_btn.config(font=("Helvetica", 12, "bold"))
        self.apply_timers_btn.place(x=1000, y=90, width=160, height=36)

        # Period Settings Row
        tk.Label(self.main_window, text="Start", font=("Arial", 10)).place(x=750, y=150)
        self.start_time_var = tk.StringVar(value="10:00")
        tk.Entry(self.main_window, textvariable=self.start_time_var, width=8).place(x=790, y=150)
        
        tk.Label(self.main_window, text="Duration(m)", font=("Arial", 10)).place(x=860, y=150)
        self.period_duration_var = tk.IntVar(value=60)
        tk.Spinbox(self.main_window, from_=1, to=480, textvariable=self.period_duration_var, width=5).place(x=940, y=150)
        
        self.set_period_btn = utils.get_button(self.main_window, 'Set Period', 'purple', self.set_period)
        self.set_period_btn.config(font=("Helvetica", 12, "bold"))
        self.set_period_btn.place(x=1000, y=140, width=160, height=36)

        # Buttons in 2x3 Grid
        # Row 1
        self.login_button_main_window = utils.get_button(self.main_window, 'Login', 'blue', self.login)
        self.login_button_main_window.config(width=13, font=("Helvetica", 15, "bold"))
        self.login_button_main_window.place(x=750, y=220)

        self.logout_button_main_window = utils.get_button(self.main_window, 'Logout', 'red', self.logout)
        self.logout_button_main_window.config(width=13, font=("Helvetica", 15, "bold"))
        self.logout_button_main_window.place(x=970, y=220)

        # Row 2
        self.register_button_main_window = utils.get_button(self.main_window, 'Register', 'black', self.Register, fg='white')
        self.register_button_main_window.config(width=13, font=("Helvetica", 15, "bold"))
        self.register_button_main_window.place(x=750, y=300)

        self.view_attendance_button = utils.get_button(self.main_window, 'View Attendance', 'green', self.view_attendance)
        self.view_attendance_button.config(width=13, font=("Helvetica", 15, "bold"))
        self.view_attendance_button.place(x=970, y=300)

        # Row 3
        self.manage_dept_button = utils.get_button(self.main_window, 'Manage Departments', 'purple', self.manage_departments)
        self.manage_dept_button.config(width=13, font=("Helvetica", 15, "bold"))
        self.manage_dept_button.place(x=750, y=380)

        self.manage_class_button = utils.get_button(self.main_window, 'Manage Classes', 'orange', self.manage_classes)
        self.manage_class_button.config(width=13, font=("Helvetica", 15, "bold"))
        self.manage_class_button.place(x=970, y=380)
        
        # Row 4 - Train Model & Manage Students
        self.train_btn = utils.get_button(self.main_window, 'Train Model', 'darkblue', self.train_model_ui, fg='white')
        self.train_btn.config(width=13, font=("Helvetica", 15, "bold"))
        self.train_btn.place(x=750, y=460)

        self.manage_student_btn = utils.get_button(self.main_window, 'Manage Students', 'teal', self.manage_students_ui, fg='white')
        self.manage_student_btn.config(width=13, font=("Helvetica", 15, "bold"))
        self.manage_student_btn.place(x=970, y=460)

        # Countdown Labels
        self.timer_label = tk.Label(self.main_window, text="", font=("Arial", 12), fg="blue")
        self.timer_label.place(x=780, y=190)

        self.logout_timer_label = tk.Label(self.main_window, text="", font=("Arial", 12), fg="red")
        self.logout_timer_label.place(x=970, y=190)
        
        self.period_status_label = tk.Label(self.main_window, text="", font=("Arial", 12), fg="purple")
        self.period_status_label.place(x=750, y=520)
        
        # Login Timer Clock Icon
        self.login_clock_icon = self.create_clock_icon(size=30)
        self.login_clock_label = tk.Label(self.main_window, image=self.login_clock_icon)

        # Webcam display
        self.webcam_label = utils.get_img_label(self.main_window)
        self.webcam_label.place(x=0, y=0, width=700, height=500)
        
        # Initialize webcam
        self.add_webcam(self.webcam_label)


    def create_clock_icon(self, size=24):
        """Create an attractive clock icon with gradient effect"""
        # Create a blank image with transparent background
        image = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        
        # Draw clock face with gradient effect
        center = size // 2
        radius = size // 2
        
        # Create gradient background
        for r in range(radius, 0, -1):
            # Calculate color based on radius (outer to inner gradient)
            ratio = r / radius
            if ratio > 0.9:  # Outer ring is darker
                fill_color = (180, 180, 240, 255)
            else:  # Inner part gets progressively lighter
                blue = int(220 + (255-220) * (1-ratio))
                fill_color = (240, 240, blue, 255)
            
            # Draw circle for this radius
            draw.ellipse(
                [(center-r, center-r), (center+r, center+r)], 
                outline=None, 
                fill=fill_color
            )
        
        # Draw outer border
        draw.ellipse(
            [(0, 0), (size-1, size-1)], 
            outline=(100, 100, 180), 
            width=2
        )
        
        # Draw hour tick marks
        for i in range(12):
            angle = math.radians(i * 30)
            outer_x = center + (radius-2) * math.sin(angle)
            outer_y = center - (radius-2) * math.cos(angle)
            inner_x = center + (radius-5) * math.sin(angle)
            inner_y = center - (radius-5) * math.cos(angle)
            # Make 3, 6, 9, 12 slightly thicker
            thickness = 2 if i % 3 == 0 else 1
            draw.line([(outer_x, outer_y), (inner_x, inner_y)], fill=(80, 80, 160), width=thickness)
        
        # Draw clock center
        draw.ellipse(
            [(center-2, center-2), (center+2, center+2)], 
            fill=(60, 60, 120)
        )
        
        # Draw hour hand (pointing to 2)
        hour_angle = math.radians(60)  # 2 o'clock position
        hour_length = size // 3
        hour_x = center + hour_length * math.sin(hour_angle)
        hour_y = center - hour_length * math.cos(hour_angle)
        draw.line(
            [(center, center), (hour_x, hour_y)], 
            fill=(60, 60, 120), 
            width=3
        )
        
        # Draw minute hand (pointing to 10)
        minute_angle = math.radians(300)  # 10 o'clock position
        minute_length = size // 2.5
        minute_x = center + minute_length * math.sin(minute_angle)
        minute_y = center - minute_length * math.cos(minute_angle)
        draw.line(
            [(center, center), (minute_x, minute_y)], 
            fill=(60, 60, 120), 
            width=2
        )
        
        # Add a small shadow effect
        shadow_offset = 1
        shadow_color = (0, 0, 0, 80)  # Semi-transparent black
        
        # Convert to PhotoImage for tkinter
        return ImageTk.PhotoImage(image)
    
    def add_webcam(self,label):

        if 'cap' not in self.__dict__:
            self.cap = cv2.VideoCapture(0)

        # we this this becz we cant simply take the input every time so we call the function by this function
        self._label = label
        self.process_webcam()

# we did not read the image dirrectly from the cv because it has some problem in opening the jpg file
    # so we use pillow in order to do as it has func called ImageTK

    def process_webcam(self):
        ret, frame = self.cap.read()
        self.recent_frame = frame
        
        # Check if frame is valid before processing
        if frame is None:
            # Handle case when camera is not available
            # Create a blank frame with message
            height, width = 480, 640
            frame = np.zeros((height, width, 3), dtype=np.uint8)
            cv2.putText(frame, "Camera not available", (width//4, height//2), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            self.recent_frame = frame
            
            # Display the frame and schedule next update
            img_ = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self.recent_Pil = Image.fromarray(img_)
            imgtk = ImageTk.PhotoImage(image=self.recent_Pil)
            self._label.imgtk = imgtk
            self._label.configure(image=imgtk)
            self._label.after(1000, self.process_webcam)  # Try again after 1 second
            return
        
        # Convert to grayscale for face detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Load the face cascade classifier
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        # Detect faces
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        
        # Process detected faces
        if len(faces) > 0:
            # Sort faces by area (largest first)
            faces = sorted(faces, key=lambda x: x[2]*x[3], reverse=True)
            
            # Draw rectangles and labels for all detected faces
            for i, (x, y, w, h) in enumerate(faces):
                # Different colors for different faces
                colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0), (0, 255, 255)]
                color = colors[i % len(colors)]
                
                # Draw rectangle around face
                cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                
                # Add face number label
                cv2.putText(frame, f"Face #{i+1}", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                
                # If user is logged in, check if this is the logged-in user's face
                if self.logged_in and self.face_detection_active:
                    # Reset logout timer if faces are detected (using the first/largest face as trigger)
                    if i == 0:
                        self.last_face_detected_time = time.time()
                        # Cancel any pending logout timer
                        if self.face_absent_timer is not None:
                            self.face_absent_timer.cancel()
                            self.face_absent_timer = None
                        # Reset logout countdown
                        self.logout_countdown = self.logout_duration
                        # Update logout timer display
                        self.logout_timer_label.config(text="")
                    
                    # Label faces based on login state
                    if "," in self.current_user:
                        # Multiple users logged in - label all faces as Active since we can't distinguish without re-recognition
                        cv2.putText(frame, "Active", (x, y+h+20), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                    else:
                        # Single user logged in - assume largest face (i=0) is the logged-in user
                        if i == 0:
                            cv2.putText(frame, f"User: {self.current_user}", (x, y+h+20), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                        else:
                            # Label other faces as unknown
                            cv2.putText(frame, "Unknown", (x, y+h+20), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
            
            # Display the count of detected faces
            cv2.putText(frame, f"Detected: {len(faces)} face(s)", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
        
        # If user is logged in but no faces detected, handle logout timer
        elif self.logged_in and self.face_detection_active and self.last_face_detected_time is not None:
            current_time = time.time()
            time_since_last_detection = current_time - self.last_face_detected_time
            
            # Update logout countdown display with attractive formatting
            seconds_remaining = max(0, self.logout_duration - int(time_since_last_detection))
            self.logout_countdown = seconds_remaining
            if seconds_remaining > 0:
                # Change color based on urgency (red gets brighter as time decreases)
                ratio = seconds_remaining / self.logout_duration if self.logout_duration > 0 else 0
                intensity = int(105 + (150 * (1 - ratio)))
                intensity = max(0, min(255, intensity))
                color = f"#{intensity:02x}0000"  # Brighter red as time decreases
                self.logout_timer_label.config(
                    text=f"Auto logout in: {seconds_remaining}s",
                    fg=color,
                    font=("Arial", 14, "bold")
                )
            
            # If face has been absent for more than logout_duration seconds and no timer is running
            if time_since_last_detection >= self.logout_duration and self.face_absent_timer is None:
                # Start auto-logout timer
                self.face_absent_timer = threading.Timer(0.1, self.auto_logout)
                self.face_absent_timer.start()
            
            # Display message about no faces detected
            cv2.putText(frame, "No faces detected", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
        
        # converting to format which other than cv2 understand from BGR to RGB
        img_ = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # now converting the array image read by the cv2 to pillow format
        self.recent_Pil = Image.fromarray(img_)
        imgtk = ImageTk.PhotoImage(image=self.recent_Pil)  # here converting in which the tk will understand
        self._label.imgtk = imgtk
        self._label.configure(image=imgtk)

        self._label.after(20, self.process_webcam)

    def apply_timers(self):
        try:
            self.login_duration = self.login_duration_var.get()
            self.logout_duration = self.logout_duration_var.get()
            utils.msg_box("Success", "Timer settings updated!")
        except ValueError:
            utils.msg_box("Error", "Invalid timer values")

    def set_period(self):
        start_time = self.start_time_var.get()
        duration_min = int(self.period_duration_var.get())
        now = datetime.datetime.now()
        try:
            hh, mm = [int(x) for x in start_time.split(":")]
        except Exception:
            utils.msg_box("Error", "Start time must be in HH:MM format")
            return
        target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if target < now:
            target = target + datetime.timedelta(days=1)
        end_dt = target + datetime.timedelta(minutes=duration_min)

        if self.period_start_job:
            try:
                self.main_window.after_cancel(self.period_start_job)
            except Exception:
                pass
        if self.period_end_job:
            try:
                self.main_window.after_cancel(self.period_end_job)
            except Exception:
                pass

        self.period_start_dt = target
        self.period_end_dt = end_dt
        start_delay_ms = max(0, int((target - now).total_seconds() * 1000))
        end_delay_ms = max(0, int((end_dt - now).total_seconds() * 1000))

        self.period_start_job = self.main_window.after(start_delay_ms, self.on_period_start)
        self.period_end_job = self.main_window.after(end_delay_ms, self.on_period_end)

        self.period_status_label.config(text=f"Period scheduled: {target.strftime('%H:%M')} for {duration_min}m")
        utils.msg_box("Success", f"Period set: Start {target.strftime('%H:%M')}, Duration {duration_min}m")

    def on_period_start(self):
        self.period_active = True
        self.period_status_label.config(text=f"Period active. Ends at {self.period_end_dt.strftime('%H:%M')}")
        self.update_period_timer()

    def on_period_end(self):
        self.period_active = False
        self.period_status_label.config(text="Period ended")
        if self.logged_in:
            try:
                current_users_list = [u.strip() for u in (self.current_user.split(",") if self.current_user else [])]
                if current_users_list:
                    self.perform_logout(current_users_list)
            except Exception:
                pass

    def update_period_timer(self):
        if not self.period_active or not self.period_end_dt:
            return
        now = datetime.datetime.now()
        remaining = int((self.period_end_dt - now).total_seconds())
        if remaining <= 0:
            self.on_period_end()
            return
        mins = remaining // 60
        secs = remaining % 60
        self.period_status_label.config(text=f"Period active: {mins:02d}:{secs:02d} remaining")
        self.main_window.after(1000, self.update_period_timer)

    def start(self):
        # Start auto-login timer after 20 seconds
        self.schedule_auto_login()
        self.main_window.mainloop() # for every time we run the whole program mainloop is used
        
    def schedule_auto_login(self):
        if not self.login_scheduled:
            self.login_scheduled = True
            self.login_countdown = self.login_duration  # Set initial countdown
            self.update_login_timer()
            
    def update_login_timer(self):
        if self.login_countdown > 0 and not self.logged_in:
            # Update timer display with attractive color transition
            # Color transitions from light blue to deep blue as countdown progresses
            ratio = self.login_countdown / self.login_duration if self.login_duration > 0 else 0
            intensity = int(100 + (155 * ratio))
            intensity = max(0, min(255, intensity))
            color = f"#0000{intensity:02x}"  # Deeper blue as time decreases
            
            # Add animation effect by changing font weight
            font_weight = "bold"
            
            self.timer_label.config(
                text=f"Auto login in: {self.login_countdown}s",
                fg=color,
                font=("Arial", 14, font_weight)
            )
            
            self.login_countdown -= 1
            # Schedule next update in 1 second
            self.main_window.after(1000, self.update_login_timer)
        elif self.login_countdown <= 0 and not self.logged_in:
            # Time's up, trigger auto login
            self.timer_label.config(text="")
            self.auto_login()
            
    def auto_login(self):
        if not self.logged_in:
            self.login()

    def login(self):
        # Get the model directory path
        model_dir = os.path.join(self.current_dir, 'anti_spoof_models')
        
        # Require a visible face before attempting login
        if self.recent_frame is None:
            utils.msg_box("Error!", "No camera frame available. Please check your webcam.")
            return
        try:
            _gray = cv2.cvtColor(self.recent_frame, cv2.COLOR_BGR2GRAY)
            _face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
            _faces = _face_cascade.detectMultiScale(_gray, 1.2, 5)
        except Exception:
            _faces = []
        if len(_faces) == 0:
            utils.msg_box("Error!", "No face detected. Please stand in front of the camera.")
            return
        # Check largest face size to avoid false triggers from tiny detections
        _faces = sorted(_faces, key=lambda x: x[2]*x[3], reverse=True)
        _x, _y, _w, _h = _faces[0]
        if (_w * _h) < 9000:
            utils.msg_box("Error!", "Face too small or too far. Move closer to the camera.")
            return
        
        # Run anti-spoofing test
        label = test(
            image=self.recent_frame,
            model_dir=model_dir,
            device_id=0
        )

        if label == 1:
            # Save the current frame as a temporary image
            temp_img_path = os.path.join(self.unknown_dir, 'temp.jpg')
            cv2.imwrite(temp_img_path, self.recent_frame)
            
            # Get list of registered users from all departments and classes
            registered_users = []
            for dept_name, classes in self.departments.items():
                for class_name, students in classes.items():
                    class_dir = os.path.join(self.departments_dir, dept_name, class_name)
                    if os.path.exists(class_dir):
                        for student_img in os.listdir(class_dir):
                            if student_img.endswith('.jpg'):
                                registered_users.append({
                                    'path': os.path.join(class_dir, student_img),
                                    'name': os.path.splitext(student_img)[0],
                                    'department': dept_name,
                                    'class': class_name
                                })

            # Fallback: include images from known_people folder if present
            if os.path.exists(self.known_people_dir):
                for fname in os.listdir(self.known_people_dir):
                    if fname.lower().endswith('.jpg') or fname.lower().endswith('.png'):
                        registered_users.append({
                            'path': os.path.join(self.known_people_dir, fname),
                            'name': os.path.splitext(fname)[0],
                            'department': 'UnknownDept',
                            'class': 'UnknownClass'
                        })
            
            if not registered_users:
                utils.msg_box("Error!", "No registered users found. Please register first.")
                if os.path.exists(temp_img_path):
                    os.remove(temp_img_path)
                return
            
            self.safe_update_status("Recognizing... Please hold still", "blue")
            self.main_window.update()
            frames_to_collect = 15
            all_matches = []
            for _ in range(frames_to_collect):
                self.main_window.update()
                if self.recent_frame is not None:
                    frame_matches = self.find_all_face_matches(self.recent_frame, registered_users)
                    for m in frame_matches:
                        all_matches.append(m)
                time.sleep(0.05)
            
            if all_matches:
                self.logged_in = True
                
                # Group matches by name to find the best score per user
                best_matches = {}
                occurrence_counts = {}
                for m in all_matches:
                    name = m['name']
                    conf = m.get('confidence', 0)
                    dist = m.get('distance', float('inf'))
                    method = m.get('method', 'Unknown')
                    occurrence_counts[name] = occurrence_counts.get(name, 0) + 1
                    
                    if name not in best_matches:
                        best_matches[name] = m
                    else:
                        curr = best_matches[name]
                        curr_conf = curr.get('confidence', 0)
                        curr_dist = curr.get('distance', float('inf'))
                        curr_method = curr.get('method', 'Unknown')
                        
                        if method == 'LBPH' and curr_method == 'LBPH':
                            if dist < curr_dist:
                                best_matches[name] = m
                        elif method == 'NCC' and curr_method == 'NCC':
                            if conf > curr_conf:
                                best_matches[name] = m
                        elif method == 'LBPH':
                            best_matches[name] = m
                
                min_occurrences = math.ceil(frames_to_collect / 2)
                matches = [m for m in best_matches.values() if occurrence_counts.get(m['name'], 0) >= min_occurrences]
                
                # Get currently logged in users
                current_users = []
                if self.current_user:
                    current_users = [u.strip() for u in self.current_user.split(",")]

                # Collect new names and record attendance for each match
                new_login_names = []
                
                for match in matches:
                    name = match['name']
                    dept = match['department']
                    cls = match['class']
                    
                    # Only login if not already logged in
                    if name not in current_users:
                        current_users.append(name)
                        new_login_names.append(name)
                        # Record login in attendance database
                        self.record_attendance(name, "in", dept, cls)
                
                if new_login_names:
                    # Update current user info (comma separated for multiple)
                    self.current_user = ", ".join(current_users)
                    
                    # Update status label
                    self.safe_update_status(f"Logged in: {self.current_user}", "green")
                    
                    # Clear timer display
                    self.timer_label.config(text="")
                    self.login_scheduled = False
                    
                    # Start face detection tracking
                    self.face_detection_active = True
                    self.last_face_detected_time = time.time()
                    
                    for m in matches:
                        if m['name'] in new_login_names:
                            name = m['name']
                            dept = m.get('department', 'N/A')
                            cls = m.get('class', 'N/A')
                            method = m.get('method', 'Unknown')
                            if method == 'LBPH':
                                metric = f"Distance: {m.get('distance', 0):.1f}"
                            else:
                                metric = f"Confidence: {int(m.get('confidence', 0))}%"
                            utils.msg_box(
                                f"Login Success - {name}",
                                f"Department: {dept}\nClass: {cls}\n{metric} ({method})\nAuto logout if absent for {self.logout_duration}s."
                            )
                else:
                    if best_matches and not matches:
                        utils.msg_box("Info", "Face detected but not stable enough. Please hold still.")
                    else:
                        utils.msg_box("Info", "User(s) already logged in!")
            else:
                utils.msg_box("Error!", "No recognized faces found. Please register or try again.")
            
            # Clean up the temporary file
            if os.path.exists(temp_img_path):
                os.remove(temp_img_path)
        else:
            utils.msg_box('Spoof Detected!', 'You are using a fake face or photo!')
            
    def load_face_recognizer(self):
        try:
            model_path = os.path.join(self.trainer_dir, 'classifier.xml')
            names_path = os.path.join(self.trainer_dir, 'names.json')
            
            if os.path.exists(model_path) and os.path.exists(names_path):
                # Initialize LBPH Face Recognizer
                self.face_recognizer = cv2.face.LBPHFaceRecognizer_create()
                self.face_recognizer.read(model_path)
                
                with open(names_path, 'r') as f:
                    self.user_map = json.load(f)
                
                print(f"Face recognizer loaded successfully with {len(self.user_map)} users.")
            else:
                print("No trained model found. Please train the model.")
                self.face_recognizer = None
        except Exception as e:
            print(f"Error loading face recognizer: {e}")
            self.face_recognizer = None

    def load_deep_face_embeddings(self):
        """Load and compute embeddings for all registered users using FaceNet"""
        print("Loading deep face embeddings...")
        self.known_embeddings = []
        
        # 1. Process Departments
        if os.path.exists(self.departments_dir):
            for dept_name in os.listdir(self.departments_dir):
                dept_path = os.path.join(self.departments_dir, dept_name)
                if not os.path.isdir(dept_path): continue
                
                for class_name in os.listdir(dept_path):
                    class_path = os.path.join(dept_path, class_name)
                    if not os.path.isdir(class_path): continue
                    
                    for image_name in os.listdir(class_path):
                        if not (image_name.endswith('.jpg') or image_name.endswith('.png')): continue
                        
                        image_path = os.path.join(class_path, image_name)
                        name = os.path.splitext(image_name)[0].lower()
                        
                        try:
                            img = Image.open(image_path).convert('RGB')
                            # Get cropped face directly from MTCNN
                            img_cropped = self.mtcnn(img)
                            
                            if img_cropped is not None:
                                # Calculate embedding
                                img_embedding = self.resnet(img_cropped.unsqueeze(0).to(self.device))
                                self.known_embeddings.append({
                                    'name': name,
                                    'department': dept_name,
                                    'class': class_name,
                                    'embedding': img_embedding.detach().cpu(),
                                    'path': image_path
                                })
                                print(f"Loaded embedding for {name}")
                            else:
                                print(f"No face detected in {image_path}")
                        except Exception as e:
                            print(f"Error loading {image_path}: {e}")

        # 2. Process Known People
        if os.path.exists(self.known_people_dir):
            for image_name in os.listdir(self.known_people_dir):
                if not (image_name.endswith('.jpg') or image_name.endswith('.png')): continue
                
                image_path = os.path.join(self.known_people_dir, image_name)
                name = os.path.splitext(image_name)[0].lower()
                
                try:
                    img = Image.open(image_path).convert('RGB')
                    img_cropped = self.mtcnn(img)
                    
                    if img_cropped is not None:
                        img_embedding = self.resnet(img_cropped.unsqueeze(0).to(self.device))
                        self.known_embeddings.append({
                            'name': name,
                            'department': 'Unknown',
                            'class': 'Unknown',
                            'embedding': img_embedding.detach().cpu(),
                            'path': image_path
                        })
                        print(f"Loaded embedding for {name}")
                    else:
                        print(f"No face detected in {image_path}")
                except Exception as e:
                    print(f"Error loading {image_path}: {e}")
        
        print(f"Loaded {len(self.known_embeddings)} deep face embeddings.")


    def train_model_ui(self):
        """UI Wrapper to trigger model training"""
        confirm = messagebox.askyesno("Train Model", "This will train the face recognition model with all registered users.\nIt may take a few minutes. Continue?")
        if confirm:
            # Disable train button to prevent double clicking
            self.train_btn.config(state='disabled', text="Training...")
            self.safe_update_status("Training Model... Please Wait", "blue")
            
            # Run training in a separate thread
            threading.Thread(target=self.train_model_thread, daemon=True).start()

    def train_model_thread(self):
        """Thread to handle model training"""
        try:
            path = self.departments_dir
            known_path = self.known_people_dir
            
            faces = []
            ids = []
            names = {}
            current_id = 0
            
            # 1. Process Departments (Students)
            if os.path.exists(path):
                for dept_name in os.listdir(path):
                    dept_path = os.path.join(path, dept_name)
                    if not os.path.isdir(dept_path):
                        continue
                        
                    for class_name in os.listdir(dept_path):
                        class_dir = os.path.join(dept_path, class_name)
                        if not os.path.isdir(class_dir):
                            continue
                            
                        for image_name in os.listdir(class_dir):
                            image_path = os.path.join(class_dir, image_name)
                            
                            # Read image
                            img_pil = Image.open(image_path).convert('L') # Convert to grayscale
                            image_np = np.array(img_pil, 'uint8')
                            
                            # Get name from filename (remove extension)
                            name = os.path.splitext(image_name)[0].lower()
                            
                            # Assign ID if new name
                            if name not in [v['name'] for v in names.values()]:
                                current_id += 1
                                names[str(current_id)] = {'name': name, 'department': dept_name, 'class': class_name}
                            
                            # Find the ID for this name
                            label_id = -1
                            for k, v in names.items():
                                if v['name'] == name:
                                    label_id = int(k)
                                    break
                            
                            if label_id != -1:
                                # Detect face in the training image
                                face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
                                detected_faces = face_cascade.detectMultiScale(image_np)
                                
                                if len(detected_faces) == 0:
                                    print(f"Warning: No face detected in {image_path}. This image will be ignored.")
                                
                                for (x, y, w, h) in detected_faces:
                                    _roi = image_np[y:y+h, x:x+w]
                                    _roi = cv2.equalizeHist(_roi)
                                    _roi = cv2.resize(_roi, (200, 200))
                                    faces.append(_roi)
                                    ids.append(label_id)

            # 2. Process Known People
            if os.path.exists(known_path):
                for image_name in os.listdir(known_path):
                    if not (image_name.endswith('.jpg') or image_name.endswith('.png')):
                        continue
                        
                    image_path = os.path.join(known_path, image_name)
                    
                    # Read image
                    img_pil = Image.open(image_path).convert('L')
                    image_np = np.array(img_pil, 'uint8')
                    
                    name = os.path.splitext(image_name)[0].lower()
                    
                    if name not in [v['name'] for v in names.values()]:
                        current_id += 1
                        names[str(current_id)] = {'name': name, 'department': 'Unknown', 'class': 'Unknown'}
                    
                    label_id = -1
                    for k, v in names.items():
                        if v['name'] == name:
                            label_id = int(k)
                            break
                    
                    if label_id != -1:
                        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
                        detected_faces = face_cascade.detectMultiScale(image_np)
                        
                        if len(detected_faces) == 0:
                            print(f"Warning: No face detected in {image_path}. This image will be ignored.")
                        
                        for (x, y, w, h) in detected_faces:
                            _roi = image_np[y:y+h, x:x+w]
                            _roi = cv2.equalizeHist(_roi)
                            _roi = cv2.resize(_roi, (200, 200))
                            faces.append(_roi)
                            ids.append(label_id)

            if len(faces) > 0 and len(ids) > 0:
                # Train the recognizer
                recognizer = cv2.face.LBPHFaceRecognizer_create()
                recognizer.train(faces, np.array(ids))
                
                # Filter names to only include those with training data
                used_ids = set(ids)
                final_names = {k: v for k, v in names.items() if int(k) in used_ids}
                
                # Save the model
                recognizer.save(os.path.join(self.trainer_dir, 'classifier.xml'))
                
                # Save the name mapping
                with open(os.path.join(self.trainer_dir, 'names.json'), 'w') as f:
                    json.dump(final_names, f)
                
                messagebox.showinfo("Success", f"Model trained successfully with {len(final_names)} unique people.\nNote: Some images might be skipped if no face was detected.")
                
                # Reload the recognizer in the main thread
                def reload_all():
                    self.load_face_recognizer()
                    self.load_deep_face_embeddings()
                self.main_window.after(0, reload_all)
            else:
                messagebox.showwarning("Warning", "No faces found to train. Please add images to departments or known_people.")

        except Exception as e:
            messagebox.showerror("Error", f"Training failed: {e}")
            print(e)
        finally:
            # Re-enable button
            self.main_window.after(0, lambda: self.train_btn.config(state='normal', text="Train Model"))
            self.main_window.after(0, lambda: self.safe_update_status("Not logged in", "red"))

    def find_all_face_matches(self, current_frame, registered_users):
        """Find all matching faces using FaceNet (ResNet)"""
        # Convert current frame to grayscale for face detection
        current_gray = cv2.cvtColor(current_frame, cv2.COLOR_BGR2GRAY)
        
        # Load the face cascade classifier
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        # Detect faces in the current frame
        faces = face_cascade.detectMultiScale(current_gray, 1.1, 5)
        
        # If no faces detected, return empty list
        if len(faces) == 0:
            return []
        
        matches = []
        
        # Sort faces by area (largest first)
        faces = sorted(faces, key=lambda x: x[2]*x[3], reverse=True)
        
        for (x, y, w, h) in faces:
            # Draw rectangle around the detected face
            cv2.rectangle(current_frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            
            # Extract face ROI
            face_roi = current_frame[y:y+h, x:x+w]
            
            try:
                # Preprocess for FaceNet
                img = Image.fromarray(cv2.cvtColor(face_roi, cv2.COLOR_BGR2RGB))
                img_resized = img.resize((160, 160))
                img_tensor = torch.tensor(np.array(img_resized)).permute(2, 0, 1).float()
                img_tensor = (img_tensor - 127.5) / 128.0
                
                img_embedding = self.resnet(img_tensor.unsqueeze(0).to(self.device)).detach().cpu()
                
                best_match = None
                min_dist = 100.0
                
                for known in self.known_embeddings:
                    dist = (img_embedding - known['embedding']).norm().item()
                    if dist < min_dist:
                        min_dist = dist
                        best_match = known
                
                # Threshold
                # 0.8-1.0 is typical for L2 distance on VGGface2
                if min_dist < 0.9 and best_match:
                    match_info = best_match.copy()
                    match_info['distance'] = min_dist
                    match_info['method'] = 'FaceNet'
                    matches.append(match_info)
                    
                    cv2.putText(current_frame, f"{best_match['name']} ({min_dist:.2f})", (x, y-10), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                else:
                    cv2.putText(current_frame, f"Unknown ({min_dist:.2f})", (x, y-10), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            except Exception as e:
                print(f"FaceNet error: {e}")
                
        return matches
        
    def record_attendance(self, user, status, department=None, class_name=None):
        """Record attendance with timestamp and department/class information"""
        # Get current date and time
        now = datetime.datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M:%S")
        
        # Get department and class information
        if department is None:
            department = self.current_department
        if class_name is None:
            class_name = self.current_class
        
        # Load existing attendance data
        attendance_data = {}
        if os.path.exists(self.attendance_db):
            with open(self.attendance_db, 'r') as f:
                try:
                    attendance_data = json.load(f)
                except json.JSONDecodeError:
                    attendance_data = {}
        
        # Initialize date entry if it doesn't exist
        if date_str not in attendance_data:
            attendance_data[date_str] = {}
        
        # Initialize department entry if it doesn't exist
        if department not in attendance_data[date_str]:
            attendance_data[date_str][department] = {}
            
        # Initialize class entry if it doesn't exist
        if class_name not in attendance_data[date_str][department]:
            attendance_data[date_str][department][class_name] = {}
            
        # Initialize user entry if it doesn't exist
        if user not in attendance_data[date_str][department][class_name]:
            attendance_data[date_str][department][class_name][user] = []
        
        student_info = self.student_data.get(user, {})
        attendance_data[date_str][department][class_name][user].append({
            "time": time_str,
            "status": status,
            "student_id": student_info.get("id")
        })
        
        # Save updated attendance data
        with open(self.attendance_db, 'w') as f:
            json.dump(attendance_data, f, indent=4)
            
        # Also append to log_data.txt for backward compatibility
        with open('log_data.txt', 'a') as f:
            f.write(f'{user},{department},{class_name},{now},{status}\n')


    def Register(self):
        self.register_new_window = tk.Toplevel(self.main_window)
        self.register_new_window.geometry('1200x600')
        self.register_new_window.title("Student Registration")
        
        # Capture image area
        self.capture_label = utils.get_img_label(self.register_new_window)
        self.capture_label.place(x=10, y=10, width=700, height=500)
        self.add_img_to_label(self.capture_label)
        
        # Form frame
        form_frame = tk.Frame(self.register_new_window, bd=2, relief=tk.RIDGE)
        form_frame.place(x=720, y=10, width=460, height=580)
        
        # Form title
        title_label = tk.Label(form_frame, text="Student Registration Form", font=("Arial", 16, "bold"))
        title_label.pack(pady=10)
        
        # Student information fields
        tk.Label(form_frame, text="Student Name:", font=("Arial", 12)).pack(anchor="w", padx=20, pady=(10,0))
        self.entry_text_register_new_user = utils.get_entry_text(form_frame)
        self.entry_text_register_new_user.pack(fill="x", padx=20, pady=(0,10))
        
        tk.Label(form_frame, text="Student ID:", font=("Arial", 12)).pack(anchor="w", padx=20, pady=(10,0))
        self.entry_student_id = utils.get_entry_text(form_frame)
        self.entry_student_id.pack(fill="x", padx=20, pady=(0,10))
        
        # Department selection
        tk.Label(form_frame, text="Department:", font=("Arial", 12)).pack(anchor="w", padx=20, pady=(10,0))
        self.dept_var = tk.StringVar()
        self.dept_dropdown = ttk.Combobox(form_frame, textvariable=self.dept_var, font=("Arial", 12), state="readonly")
        self.dept_dropdown['values'] = list(self.departments.keys())
        if self.dept_dropdown['values']:
            self.dept_dropdown.current(0)
        self.dept_dropdown.pack(fill="x", padx=20, pady=(0,10))
        
        # Class selection (will be populated based on department)
        tk.Label(form_frame, text="Class:", font=("Arial", 12)).pack(anchor="w", padx=20, pady=(10,0))
        self.class_var = tk.StringVar()
        self.class_dropdown = ttk.Combobox(form_frame, textvariable=self.class_var, font=("Arial", 12), state="readonly")
        self.class_dropdown.pack(fill="x", padx=20, pady=(0,10))
        
        # Update class dropdown when department changes
        def on_dept_change(event):
            selected_dept = self.dept_var.get()
            if selected_dept in self.departments:
                self.class_dropdown['values'] = list(self.departments[selected_dept].keys())
                if self.class_dropdown['values']:
                    self.class_dropdown.current(0)
        
        self.dept_dropdown.bind("<<ComboboxSelected>>", on_dept_change)
        
        # Initial class population
        if self.dept_dropdown['values']:
            selected_dept = self.dept_var.get()
            if selected_dept in self.departments:
                self.class_dropdown['values'] = list(self.departments[selected_dept].keys())
                if self.class_dropdown['values']:
                    self.class_dropdown.current(0)
        
        # Buttons
        button_frame = tk.Frame(form_frame)
        button_frame.pack(pady=20)
        
        self.accept_button = utils.get_button(button_frame, 'Register Student', 'blue', self.Accept)
        self.accept_button.pack(side="left", padx=10)
        
        self.tryagain_button = utils.get_button(button_frame, 'Try Again', 'green', self.Try_Again)
        self.tryagain_button.pack(side="left", padx=10)

    def add_img_to_label(self,label):
        imgtk = ImageTk.PhotoImage(image=self.recent_Pil)  # here converting in which the tk will understand
        label.imgtk = imgtk
        label.configure(image=imgtk)

        # we copied frames as we gonna use  opencv to save the image from the capture to our folder
        self.register_new_user_capture = self.recent_frame.copy()




    def Accept(self):
        # Get student information
        name = self.entry_text_register_new_user.get(1.0,"end-1c").strip()
        student_id = self.entry_student_id.get(1.0,"end-1c").strip()
        department = self.dept_var.get()
        class_name = self.class_var.get()
        
        # Validate inputs
        if not name:
            utils.msg_box("Error!", "Please enter a valid name!")
            return
            
        if not student_id:
            utils.msg_box("Error!", "Please enter a valid student ID!")
            return
            
        if not department:
            utils.msg_box("Error!", "Please select a department!")
            return
            
        if not class_name:
            utils.msg_box("Error!", "Please select a class!")
            return
        
        # Create directory path for the student's department and class
        class_dir = os.path.join(self.departments_dir, department, class_name)
        os.makedirs(class_dir, exist_ok=True)
        
        # Save the student's image
        image_path = os.path.join(class_dir, f"{name}.jpg")
        cv2.imwrite(image_path, self.register_new_user_capture)
        
        # Add new student data to the student_data dictionary
        if name not in self.student_data:
            self.student_data[name] = {}
            
        self.student_data[name] = {
            "id": student_id,
            "department": department,
            "class": class_name,
            "registration_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        # Save updated student data
        self.save_student_data()
        
        utils.msg_box("Success!", f"Student {name} (ID: {student_id}) registered successfully!\nDepartment: {department}\nClass: {class_name}")
        
        self.register_new_window.destroy()

        # Automatically train the model
        self.safe_update_status("Training Model... Please Wait", "blue")
        if hasattr(self, 'train_btn'):
            self.train_btn.config(state='disabled', text="Training...")
        threading.Thread(target=self.train_model_thread, daemon=True).start()

    def Try_Again(self):
        self.register_new_window.destroy()
        
    def auto_logout(self):
        """Automatically logout user when face is not detected for 10 seconds"""
        if self.logged_in:
            # Record logout in attendance database
            users = [u.strip() for u in (self.current_user.split(",") if self.current_user else [])]
            if users:
                for u in users:
                    self.record_attendance(u, "out (auto)")
            else:
                # Fallback for single user
                self.record_attendance(self.current_user, "out (auto)")
            
            # Update status label
            self.safe_update_status("Not logged in", "red")
            
            # Clear timer displays
            self.logout_timer_label.config(text="")
            self.timer_label.config(text="")
            
            # Reset login state
            self.logged_in = False
            last_user = self.current_user
            self.current_user = None
            self.face_detection_active = False
            self.last_face_detected_time = None
            
            users = [u.strip() for u in (last_user.split(",") if last_user else [])]
            if users:
                for u in users:
                    utils.msg_box("Auto Logout", f"{u} has been automatically logged out due to absence!")
            else:
                utils.msg_box("Auto Logout", "User has been automatically logged out due to absence!")
    
    def show_logout_dialog(self, users):
        # Create a Toplevel window
        logout_window = tk.Toplevel(self.main_window)
        logout_window.title("Select Users to Logout")
        logout_window.geometry("400x400")
        
        # Make it modal
        logout_window.transient(self.main_window)
        logout_window.grab_set()
        
        tk.Label(logout_window, text="Select users to logout:", font=("Arial", 14, "bold")).pack(pady=15)
        
        # Scrollable frame for users
        frame = tk.Frame(logout_window)
        frame.pack(fill="both", expand=True, padx=20)
        
        canvas = tk.Canvas(frame)
        scrollbar = tk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Checkboxes
        self.logout_vars = {}
        for user in users:
            var = tk.BooleanVar(value=False)
            self.logout_vars[user] = var
            cb = tk.Checkbutton(scrollable_frame, text=user, variable=var, font=("Arial", 12))
            cb.pack(anchor="w", padx=10, pady=5)
            
        def confirm_logout():
            selected_users = [u for u, v in self.logout_vars.items() if v.get()]
            if not selected_users:
                messagebox.showwarning("Warning", "No users selected!", parent=logout_window)
                return
            
            self.perform_logout(selected_users)
            logout_window.destroy()
            
        # Button Frame
        btn_frame = tk.Frame(logout_window)
        btn_frame.pack(pady=20)
        
        tk.Button(btn_frame, text="Logout Selected", command=confirm_logout, 
                 bg="red", fg="white", font=("Arial", 12, "bold"), padx=10).pack(side="left", padx=10)
                 
        tk.Button(btn_frame, text="Cancel", command=logout_window.destroy,
                 bg="gray", fg="white", font=("Arial", 12), padx=10).pack(side="left", padx=10)

    def perform_logout(self, users_to_logout):
        """Logout specific users"""
        if not users_to_logout:
            return
            
        # Record attendance
        for u in users_to_logout:
            self.record_attendance(u, "out")
            
        # Get current users list
        current_users_list = [u.strip() for u in (self.current_user.split(",") if self.current_user else [])]
        
        # Remove logged out users
        remaining_users = [u for u in current_users_list if u not in users_to_logout]
        
        if remaining_users:
            # Some users remain
            self.current_user = ", ".join(remaining_users)
            self.safe_update_status(f"Logged in: {self.current_user}", "green")
            for u in users_to_logout:
                utils.msg_box("Logout", f"{u} logged out. Remaining: {self.current_user}")
        else:
            # No users remain - Full Reset
            self.safe_update_status("Not logged in", "red")
            self.logout_timer_label.config(text="")
            self.timer_label.config(text="")
            
            self.logged_in = False
            self.current_user = None
            self.face_detection_active = False
            self.last_face_detected_time = None
            
            if self.face_absent_timer is not None:
                self.face_absent_timer.cancel()
                self.face_absent_timer = None
                
            for u in users_to_logout:
                utils.msg_box("Logout", f"{u} logged out.")

    def logout(self):
        """Handle user logout"""
        if not self.logged_in:
            utils.msg_box("Not Logged In", "You are not currently logged in!")
            return
            
        current_users_list = [u.strip() for u in (self.current_user.split(",") if self.current_user else [])]
        
        if len(current_users_list) > 1:
            self.show_logout_dialog(current_users_list)
        else:
            self.perform_logout(current_users_list)
    
    def view_attendance(self):
        """Display attendance records in a new window"""
        # Create a new window for attendance display
        attendance_window = tk.Toplevel(self.main_window)
        attendance_window.title("Attendance Records")
        attendance_window.geometry('1000x700')
        
        # Create a frame for filters
        filter_frame = tk.Frame(attendance_window)
        filter_frame.pack(fill="x", padx=10, pady=10)
        
        # Department filter
        tk.Label(filter_frame, text="Department:", font=("Arial", 12)).pack(side="left", padx=5)
        dept_var = tk.StringVar()
        dept_dropdown = ttk.Combobox(filter_frame, textvariable=dept_var, font=("Arial", 12), state="readonly", width=15)
        dept_dropdown['values'] = ['All'] + list(self.departments.keys())
        dept_dropdown.current(0)
        dept_dropdown.pack(side="left", padx=5)
        
        # Class filter
        tk.Label(filter_frame, text="Class:", font=("Arial", 12)).pack(side="left", padx=5)
        class_var = tk.StringVar()
        class_dropdown = ttk.Combobox(filter_frame, textvariable=class_var, font=("Arial", 12), state="readonly", width=15)
        class_dropdown['values'] = ['All']
        class_dropdown.current(0)
        class_dropdown.pack(side="left", padx=5)
        
        # Date filter
        tk.Label(filter_frame, text="Date:", font=("Arial", 12)).pack(side="left", padx=5)
        date_var = tk.StringVar()
        date_dropdown = ttk.Combobox(filter_frame, textvariable=date_var, font=("Arial", 12), state="readonly", width=15)
        
        # Load available dates from attendance data
        available_dates = ['All']
        if os.path.exists(self.attendance_db):
            with open(self.attendance_db, 'r') as f:
                try:
                    attendance_data = json.load(f)
                    available_dates.extend(list(attendance_data.keys()))
                except json.JSONDecodeError:
                    pass
        
        date_dropdown['values'] = available_dates
        date_dropdown.current(0)
        date_dropdown.pack(side="left", padx=5)
        
        # Create a frame for the attendance data
        frame = tk.Frame(attendance_window)
        frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create a treeview to display attendance data
        columns = ("Date", "Department", "Class", "Student", "Time", "Status")
        tree = tk.ttk.Treeview(frame, columns=columns, show="headings")
        
        # Define column headings
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=100, anchor="center")
        
        # Add a scrollbar
        scrollbar = tk.ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        tree.pack(side="left", fill="both", expand=True)
        
        # Function to load and filter attendance data
        def load_attendance_data():
            # Clear existing data
            for item in tree.get_children():
                tree.delete(item)
                
            if os.path.exists(self.attendance_db):
                try:
                    with open(self.attendance_db, 'r') as f:
                        attendance_data = json.load(f)
                        
                        # Get filter values
                        selected_date = date_var.get()
                        selected_dept = dept_var.get()
                        selected_class = class_var.get()
                        
                        # Populate the treeview with filtered attendance records
                        for date, data in attendance_data.items():
                            # Apply date filter
                            if selected_date != 'All' and date != selected_date:
                                continue
                            
                            # Process each entry in the date data
                            for key, value in data.items():
                                # Check if this is a user entry (old format) or department entry (new format)
                                if isinstance(value, list):
                                    # Old format - key is a username, value is a list of records
                                    # Skip if department or class filter is applied
                                    if selected_dept != 'All' or selected_class != 'All':
                                        continue
                                    
                                    user = key
                                    records = value
                                    for record in records:
                                        tree.insert("", "end", values=(
                                            date,
                                            "N/A",  # Department placeholder
                                            "N/A",  # Class placeholder
                                            user,
                                            record["time"],
                                            record["status"]
                                        ))
                                elif isinstance(value, dict):
                                    # New format - key is a department, value is a dict of classes
                                    dept = key
                                    
                                    # Apply department filter
                                    if selected_dept != 'All' and dept != selected_dept:
                                        continue
                                    
                                    classes = value
                                    for class_name, class_value in classes.items():
                                        # Apply class filter
                                        if selected_class != 'All' and class_name != selected_class:
                                            continue
                                        
                                        # Check if class_value is a dictionary (contains students)
                                        if isinstance(class_value, dict):
                                            for student, student_records in class_value.items():
                                                if isinstance(student_records, list):
                                                    for record in student_records:
                                                        tree.insert("", "end", values=(
                                                            date,
                                                            dept,
                                                            class_name,
                                                            student,
                                                            record["time"],
                                                            record["status"]
                                                        ))
                                        else:
                                            print(f"Warning: Expected dict for students but got {type(class_value)} for class {class_name}")
                                else:
                                    print(f"Warning: Unexpected data type {type(value)} for key {key}")
                except (json.JSONDecodeError, FileNotFoundError) as e:
                    print(f"Error loading attendance data: {str(e)}")
                    tk.Label(frame, text="No attendance records found", font=("Arial", 14)).pack(pady=20)
            else:
                tk.Label(frame, text="No attendance records found", font=("Arial", 14)).pack(pady=20)
        
        # Update class dropdown when department changes
        def on_dept_change(event):
            selected_dept = dept_var.get()
            
            if selected_dept == 'All':
                class_dropdown['values'] = ['All']
            elif selected_dept in self.departments:
                class_dropdown['values'] = ['All'] + list(self.departments[selected_dept].keys())
            else:
                class_dropdown['values'] = ['All']
                
            class_dropdown.current(0)
            load_attendance_data()
        
        # Bind events to filters
        dept_dropdown.bind("<<ComboboxSelected>>", on_dept_change)
        class_dropdown.bind("<<ComboboxSelected>>", lambda e: load_attendance_data())
        date_dropdown.bind("<<ComboboxSelected>>", lambda e: load_attendance_data())
        
        # Initial load of attendance data
        load_attendance_data()
        
        # Add export button
        export_button = tk.Button(
            attendance_window,
            text="Export to Excel",
            command=lambda: self.export_attendance_to_excel(),
            font=("Arial", 12),
            bg="blue",
            fg="white"
        )
        export_button.pack(pady=10)
    
    def export_attendance_to_excel(self):
        """Export attendance data to an Excel file"""
        if not os.path.exists(self.attendance_db):
            utils.msg_box("Error", "No attendance data to export!")
            return
            
        try:
            # Create export directory if it doesn't exist
            export_dir = os.path.join(self.current_dir, 'exports')
            os.makedirs(export_dir, exist_ok=True)
            
            # Generate filename with timestamp
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            export_path = os.path.join(export_dir, f'attendance_export_{timestamp}.xlsx')
            
            # Load attendance data
            with open(self.attendance_db, 'r') as f:
                attendance_data = json.load(f)
            
            # Convert to DataFrame
            rows = []
            for date, data in attendance_data.items():
                # Process each entry in the date data
                for key, value in data.items():
                    # Check if this is a user entry (old format) or department entry (new format)
                    if isinstance(value, list):
                        # Old format - key is a username, value is a list of records
                        user = key
                        records = value
                        for record in records:
                            rows.append({
                                'Date': date,
                                'Department': 'N/A',
                                'Class': 'N/A',
                                'Student': user, 
                                'Time': record['time'],
                                'Status': record['status']
                            })
                    elif isinstance(value, dict):
                        # New format - key is a department, value is a dict of classes
                        dept = key
                        classes = value
                        
                        for class_name, class_value in classes.items():
                            # Check if class_value is a dictionary (contains students)
                            if isinstance(class_value, dict):
                                for student, student_records in class_value.items():
                                    if isinstance(student_records, list):
                                        for record in student_records:
                                            rows.append({
                                                'Date': date,
                                                'Department': dept,
                                                'Class': class_name,
                                                'Student': student, 
                                                'Time': record['time'],
                                                'Status': record['status']
                                            })
                                    else:
                                        print(f"Warning: Expected list for student records but got {type(student_records)} for student {student}")
                            else:
                                print(f"Warning: Expected dict for students but got {type(class_value)} for class {class_name}")
                    else:
                        print(f"Warning: Unexpected data type {type(value)} for key {key}")

            
            df = pd.DataFrame(rows)
            df.to_excel(export_path, index=False)
            
            utils.msg_box("Export Successful", f"Attendance data exported to:\n{export_path}")
            
        except Exception as e:
            utils.msg_box("Export Failed", f"Error exporting data: {str(e)}")


    def load_departments(self):
        """Load departments and classes from the database"""
        if os.path.exists(self.departments_db):
            try:
                with open(self.departments_db, 'r') as f:
                    self.departments = json.load(f)
            except json.JSONDecodeError:
                self.departments = {}
        else:
            self.departments = {}
            
    def load_student_data(self):
         """Load student data from the database"""
         if os.path.exists(self.student_db):
             try:
                 with open(self.student_db, 'r') as f:
                     self.student_data = json.load(f)
             except json.JSONDecodeError:
                 self.student_data = {}
         else:
             self.student_data = {}
    
    def save_departments(self):
        """Save departments and classes to the database"""
        with open(self.departments_db, 'w') as f:
            json.dump(self.departments, f, indent=4)
    
    def save_student_data(self):
        """Save student data to the database"""
        with open(self.student_db, 'w') as f:
            json.dump(self.student_data, f, indent=4)
    
    def manage_departments(self):
        """Open department management window"""
        dept_window = tk.Toplevel(self.main_window)
        dept_window.title("Department Management")
        dept_window.geometry('600x500')
        
        # Frame for department list
        list_frame = tk.Frame(dept_window)
        list_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Label for department list
        tk.Label(list_frame, text="Departments", font=("Arial", 16, "bold")).pack(pady=10)
        
        # Create listbox for departments
        dept_listbox = tk.Listbox(list_frame, width=50, height=15, font=("Arial", 12))
        dept_listbox.pack(pady=10)
        
        # Populate listbox with departments
        self.refresh_department_list(dept_listbox)
        
        # Button frame
        button_frame = tk.Frame(dept_window)
        button_frame.pack(fill="x", padx=10, pady=10)
        
        # Add department button
        add_button = tk.Button(
            button_frame, 
            text="Add Department", 
            command=lambda: self.add_department(dept_listbox),
            font=("Arial", 12),
            bg="green",
            fg="white",
            padx=10,
            pady=5
        )
        add_button.pack(side="left", padx=5)
        
        # Remove department button
        remove_button = tk.Button(
            button_frame, 
            text="Remove Department", 
            command=lambda: self.remove_department(dept_listbox),
            font=("Arial", 12),
            bg="red",
            fg="white",
            padx=10,
            pady=5
        )
        remove_button.pack(side="left", padx=5)
    
    def refresh_department_list(self, listbox):
        """Refresh the department listbox"""
        listbox.delete(0, tk.END)
        for dept in self.departments.keys():
            listbox.insert(tk.END, dept)
    
    def add_department(self, listbox):
        """Add a new department"""
        dept_name = simpledialog.askstring("Add Department", "Enter department name:")
        if dept_name and dept_name.strip():
            dept_name = dept_name.strip()
            if dept_name not in self.departments:
                # Create department in database
                self.departments[dept_name] = {}
                self.save_departments()
                
                # Create department directory
                dept_dir = os.path.join(self.departments_dir, dept_name)
                os.makedirs(dept_dir, exist_ok=True)
                
                # Refresh listbox
                self.refresh_department_list(listbox)
                utils.msg_box("Success", f"Department '{dept_name}' added successfully!")
            else:
                utils.msg_box("Error", f"Department '{dept_name}' already exists!")
    
    def remove_department(self, listbox):
        """Remove a department"""
        selection = listbox.curselection()
        if selection:
            dept_name = listbox.get(selection[0])
            confirm = messagebox.askyesno(
                "Confirm Deletion", 
                f"Are you sure you want to delete department '{dept_name}'? \n\nThis will delete all classes and student data in this department!"
            )
            if confirm:
                # Remove from database
                if dept_name in self.departments:
                    del self.departments[dept_name]
                    self.save_departments()
                
                # Remove directory
                dept_dir = os.path.join(self.departments_dir, dept_name)
                if os.path.exists(dept_dir):
                    shutil.rmtree(dept_dir)
                
                # Refresh listbox
                self.refresh_department_list(listbox)
                utils.msg_box("Success", f"Department '{dept_name}' removed successfully!")
        else:
            utils.msg_box("Error", "Please select a department to remove!")
    
    def manage_classes(self):
        """Open class management window"""
        if not self.departments:
            utils.msg_box("Error", "No departments found. Please add a department first!")
            return
        
        class_window = tk.Toplevel(self.main_window)
        class_window.title("Class Management")
        class_window.geometry('800x600')
        
        # Frame for department selection
        dept_frame = tk.Frame(class_window)
        dept_frame.pack(fill="x", padx=10, pady=10)
        
        # Label for department selection
        tk.Label(dept_frame, text="Select Department:", font=("Arial", 12)).pack(side="left", padx=5)
        
        # Department dropdown
        dept_var = tk.StringVar()
        dept_dropdown = ttk.Combobox(dept_frame, textvariable=dept_var, font=("Arial", 12), state="readonly")
        dept_dropdown['values'] = list(self.departments.keys())
        if dept_dropdown['values']:
            dept_dropdown.current(0)
        dept_dropdown.pack(side="left", padx=5)
        
        # Frame for class list
        list_frame = tk.Frame(class_window)
        list_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Label for class list
        class_label = tk.Label(list_frame, text="Classes", font=("Arial", 16, "bold"))
        class_label.pack(pady=10)
        
        # Create listbox for classes
        class_listbox = tk.Listbox(list_frame, width=70, height=15, font=("Arial", 12))
        class_listbox.pack(pady=10)
        
        # Button frame
        button_frame = tk.Frame(class_window)
        button_frame.pack(fill="x", padx=10, pady=10)
        
        # Add class button
        add_button = tk.Button(
            button_frame, 
            text="Add Class", 
            command=lambda: self.add_class(dept_var.get(), class_listbox),
            font=("Arial", 12),
            bg="green",
            fg="white",
            padx=10,
            pady=5
        )
        add_button.pack(side="left", padx=5)
        
        # Remove class button
        remove_button = tk.Button(
            button_frame, 
            text="Remove Class", 
            command=lambda: self.remove_class(dept_var.get(), class_listbox),
            font=("Arial", 12),
            bg="red",
            fg="white",
            padx=10,
            pady=5
        )
        remove_button.pack(side="left", padx=5)
        
        # Bind department selection change
        def on_dept_change(event):
            self.refresh_class_list(dept_var.get(), class_listbox)
        
        dept_dropdown.bind("<<ComboboxSelected>>", on_dept_change)
        
        # Initial refresh
        if dept_dropdown['values']:
            self.refresh_class_list(dept_var.get(), class_listbox)
    
    def refresh_class_list(self, dept_name, listbox):
        """Refresh the class listbox for a department"""
        listbox.delete(0, tk.END)
        if dept_name in self.departments:
            for class_name in self.departments[dept_name].keys():
                listbox.insert(tk.END, class_name)
    
    def add_class(self, dept_name, listbox):
        """Add a new class to a department"""
        if not dept_name:
            utils.msg_box("Error", "Please select a department first!")
            return
        
        class_name = simpledialog.askstring("Add Class", f"Enter class name for department '{dept_name}':")
        if class_name and class_name.strip():
            class_name = class_name.strip()
            if dept_name in self.departments:
                if class_name not in self.departments[dept_name]:
                    # Create class in database
                    self.departments[dept_name][class_name] = {}
                    self.save_departments()
                    
                    # Create class directory
                    class_dir = os.path.join(self.departments_dir, dept_name, class_name)
                    os.makedirs(class_dir, exist_ok=True)
                    
                    # Refresh listbox
                    self.refresh_class_list(dept_name, listbox)
                    utils.msg_box("Success", f"Class '{class_name}' added to department '{dept_name}' successfully!")
                else:
                    utils.msg_box("Error", f"Class '{class_name}' already exists in department '{dept_name}'!")
    
    def remove_class(self, dept_name, listbox):
        """Remove a class from a department"""
        if not dept_name:
            utils.msg_box("Error", "Please select a department first!")
            return
        
        selection = listbox.curselection()
        if selection:
            class_name = listbox.get(selection[0])
            confirm = messagebox.askyesno(
                "Confirm Deletion", 
                f"Are you sure you want to delete class '{class_name}' from department '{dept_name}'? \n\nThis will delete all student data in this class!"
            )
            if confirm:
                # Remove from database
                if dept_name in self.departments and class_name in self.departments[dept_name]:
                    del self.departments[dept_name][class_name]
                    self.save_departments()
                
                # Remove directory
                class_dir = os.path.join(self.departments_dir, dept_name, class_name)
                if os.path.exists(class_dir):
                    shutil.rmtree(class_dir)
                
                # Refresh listbox
                self.refresh_class_list(dept_name, listbox)
                utils.msg_box("Success", f"Class '{class_name}' removed from department '{dept_name}' successfully!")
        else:
            utils.msg_box("Error", "Please select a class to remove!")

    def manage_students_ui(self):
        """Open student management window"""
        if not self.departments:
            utils.msg_box("Error", "No departments found. Please add a department first!")
            return
        
        student_window = tk.Toplevel(self.main_window)
        student_window.title("Student Management")
        student_window.geometry('900x700')
        
        # Filters Frame
        filter_frame = tk.Frame(student_window)
        filter_frame.pack(fill="x", padx=10, pady=10)
        
        # Department filter
        tk.Label(filter_frame, text="Department:", font=("Arial", 12)).pack(side="left", padx=5)
        dept_var = tk.StringVar()
        dept_dropdown = ttk.Combobox(filter_frame, textvariable=dept_var, font=("Arial", 12), state="readonly", width=15)
        dept_dropdown['values'] = list(self.departments.keys())
        if dept_dropdown['values']:
            dept_dropdown.current(0)
        dept_dropdown.pack(side="left", padx=5)
        
        # Class filter
        tk.Label(filter_frame, text="Class:", font=("Arial", 12)).pack(side="left", padx=5)
        class_var = tk.StringVar()
        class_dropdown = ttk.Combobox(filter_frame, textvariable=class_var, font=("Arial", 12), state="readonly", width=15)
        class_dropdown.pack(side="left", padx=5)
        
        # Student List Frame
        list_frame = tk.Frame(student_window)
        list_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        tk.Label(list_frame, text="Students", font=("Arial", 16, "bold")).pack(pady=5)
        
        # Treeview for students (better than listbox for details)
        columns = ("Name", "ID", "Registration Date")
        tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150, anchor="center")
            
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        tree.pack(side="left", fill="both", expand=True)
        
        # Buttons Frame
        btn_frame = tk.Frame(student_window)
        btn_frame.pack(fill="x", padx=10, pady=10)
        
        add_btn = tk.Button(
            btn_frame,
            text="Add Student",
            command=self.Register,  # Reuse existing registration
            font=("Arial", 12),
            bg="green",
            fg="white",
            padx=10
        )
        add_btn.pack(side="left", padx=10)
        
        del_btn = tk.Button(
            btn_frame,
            text="Delete Student",
            command=lambda: self.delete_student(dept_var.get(), class_var.get(), tree),
            font=("Arial", 12),
            bg="red",
            fg="white",
            padx=10
        )
        del_btn.pack(side="left", padx=10)
        
        refresh_btn = tk.Button(
            btn_frame,
            text="Refresh List",
            command=lambda: self.refresh_student_list(dept_var.get(), class_var.get(), tree),
            font=("Arial", 12),
            bg="blue",
            fg="white",
            padx=10
        )
        refresh_btn.pack(side="left", padx=10)

        # Logic to update class dropdown and list
        def on_dept_change(event):
            selected_dept = dept_var.get()
            if selected_dept in self.departments:
                classes = list(self.departments[selected_dept].keys())
                class_dropdown['values'] = classes
                if classes:
                    class_dropdown.current(0)
                    self.refresh_student_list(selected_dept, classes[0], tree)
                else:
                    class_dropdown.set('')
                    # Clear tree
                    for item in tree.get_children():
                        tree.delete(item)
        
        def on_class_change(event):
            self.refresh_student_list(dept_var.get(), class_var.get(), tree)

        dept_dropdown.bind("<<ComboboxSelected>>", on_dept_change)
        class_dropdown.bind("<<ComboboxSelected>>", on_class_change)
        
        # Initial Population
        if dept_dropdown['values']:
            # Trigger dept change to load classes and students
            on_dept_change(None)

    def refresh_student_list(self, dept, class_name, tree):
        # Clear existing
        for item in tree.get_children():
            tree.delete(item)
            
        if not dept or not class_name:
            return

        # Path to images
        class_dir = os.path.join(self.departments_dir, dept, class_name)
        if not os.path.exists(class_dir):
            return
            
        # Get students from images
        for img_file in os.listdir(class_dir):
            if img_file.lower().endswith(('.jpg', '.png', '.jpeg')):
                name = os.path.splitext(img_file)[0]
                
                # Try to get details from student_data
                student_info = self.student_data.get(name, {})
                student_id = student_info.get('id', 'N/A')
                reg_date = student_info.get('registration_date', 'N/A')
                
                # If N/A, maybe check if it matches the current dept/class in student_data
                # (Logic: student_data keys are names. If name is unique across system, this works.
                # If names are not unique, we might have issues, but current system seems to assume name uniqueness or at least uses name as key)
                
                tree.insert("", "end", values=(name, student_id, reg_date))

    def delete_student(self, dept, class_name, tree):
        selected_item = tree.selection()
        if not selected_item:
            utils.msg_box("Error", "Please select a student to delete!")
            return
            
        item_values = tree.item(selected_item[0], "values")
        name = item_values[0]
        
        confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete student '{name}'?\nThis will remove their image and data.")
        if confirm:
            # 1. Remove Image
            class_dir = os.path.join(self.departments_dir, dept, class_name)
            img_path = os.path.join(class_dir, f"{name}.jpg")
            if os.path.exists(img_path):
                try:
                    os.remove(img_path)
                except Exception as e:
                    print(f"Error removing image: {e}")
            
            # 2. Remove from student_data
            if name in self.student_data:
                del self.student_data[name]
                self.save_student_data()
                
            # 3. Remove from names.json (used for recognition) if present
            # We can't easily map name -> ID without loading names.json
            try:
                names_json_path = os.path.join(self.trainer_dir, 'names.json')
                if os.path.exists(names_json_path):
                    with open(names_json_path, 'r') as f:
                        names_map = json.load(f)
                    
                    # Find ID for name
                    id_to_remove = None
                    for id_str, data in names_map.items():
                        # The value in names.json is a dict like {"name": "...", "department": "...", "class": "..."}
                        # Or it might be just a string in some versions, but checking the file content it is a dict
                        if isinstance(data, dict):
                            if data.get('name') == name.lower():
                                id_to_remove = id_str
                                break
                        elif isinstance(data, str):
                            if data == name.lower():
                                id_to_remove = id_str
                                break
                    
                    if id_to_remove:
                        del names_map[id_to_remove]
                        with open(names_json_path, 'w') as f:
                            json.dump(names_map, f)
            except Exception as e:
                print(f"Error updating names.json: {e}")

            utils.msg_box("Success", f"Student '{name}' deleted.")
            self.refresh_student_list(dept, class_name, tree)

if __name__ == '__main__':
    obj = App()
    obj.start()
